package com.example.hexgui;  // Asegúrate de que este sea tu paquete correcto

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;

public class ResultActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Recibir información sobre el ganador
        Intent intent = getIntent();
        int winner = intent.getIntExtra("winner", 0);

        // Mostrar el mensaje correspondiente en un TextView u otro elemento
        TextView resultTextView = findViewById(R.id.resultTextView);

        if (winner == 1) {
            resultTextView.setText("Red player wins!");
        } else if (winner == 2) {
            resultTextView.setText("Blue player wins!");
        } else {
            resultTextView.setText("It's a draw!");
        }

        Button restartButton = findViewById(R.id.restartGameButton);
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start MainActivity to restart the game
                Intent intent = new Intent(ResultActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Close the current activity
            }
        });
    }
}
