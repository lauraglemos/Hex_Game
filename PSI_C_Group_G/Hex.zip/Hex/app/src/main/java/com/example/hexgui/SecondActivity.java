package com.example.hexgui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        HexagonView hexagonView = new HexagonView(this);
        hexagonView.setOnTouchListener(hexagonView);
        setContentView(hexagonView);
    }
}




