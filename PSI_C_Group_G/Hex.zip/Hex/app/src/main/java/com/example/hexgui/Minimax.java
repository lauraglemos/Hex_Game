package com.example.hexgui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class Minimax {
    public final static int boardSize = 7;
    public final static int positiveInfinity = Integer.MAX_VALUE;
    public final static int negativeInfinity = Integer.MIN_VALUE;
    public int depth;
    public int numberMoves;


    public Minimax(int depth) {
        this.depth = depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }
    public void setNumberMoves(int numberMoves) {
        this.numberMoves = numberMoves;
    }


    public int[] minimax(char[][] boardState, HashMap<String,Cell> cellHashMap, HashMap<Cell,CellRegion> islandsHashMap, int depth, int alpha, int beta, boolean maximizingPlayer) {
        int[] bestMove = new int[]{checkWinner(cellHashMap), -1, -1, depth}; // score, row, column, depth

        if (depth == 0 || checkWinner(cellHashMap) != 0){
            return evaluationFunction(bestMove, boardState, cellHashMap, islandsHashMap);
        }

        if (maximizingPlayer) { // IA Player
            int maxScore = negativeInfinity;

            // All posible moves
            for (int j = 0; j < boardSize; j++) {
                for (int i = 0; i < boardSize; i++) {
                    if (boardState[i][j] == '*') {
                        // Copy Hash Maps
                        HashMap<String,Cell> cellHashMapCopy = copyCellHashMap(boardState);
                        HashMap<Cell,CellRegion> islandsHashMapCopy = copyIslandsHashMap(cellHashMapCopy,islandsHashMap);
                        // End of copy

                        // Simulate the move
                        boardState[i][j] = 'X';
                        cellHashMapCopy.get(i + "," + j).setState(2); // Update Cell Status
                        search(cellHashMapCopy.get(i + "," + j), cellHashMapCopy, islandsHashMapCopy);

                        // Recursively call
                        int[] minimax = minimax(boardState, cellHashMapCopy, islandsHashMapCopy, depth - 1, alpha, beta, false);
                        int score = minimax[0];

                        boardState[i][j] = '*';

                        // Update best move
                        if (score > maxScore) {
                            //System.out.println("Max-score: " + score + ">" + maxScore + " row: " + i + " column: " + j);
                            maxScore = score;
                            bestMove[0] = score;
                            bestMove[1] = i;
                            bestMove[2] = j;
                        }

                        // Update alpha
                        alpha = Math.max(alpha, score);

                        // Alfa-Beta Pruning
                        if (beta <= alpha) {
                            return bestMove;
                        }
                    }
                }
            }
            return bestMove;
        } else { // Human Player
            int minScore = positiveInfinity;

            // All posible moves
            for (int i = 0; i < boardSize; i++) {
                for (int j = 0; j < boardSize; j++) {
                    if (boardState[i][j] == '*') {
                        HashMap<String,Cell> cellHashMapCopy = copyCellHashMap(boardState);
                        HashMap<Cell,CellRegion> islandsHashMapCopy = copyIslandsHashMap(cellHashMapCopy,islandsHashMap);

                        // Simulate the move
                        boardState[i][j] = '0';
                        cellHashMapCopy.get(i + "," + j).setState(1); // Update Cell Status
                        search(cellHashMapCopy.get(i + "," + j), cellHashMapCopy, islandsHashMapCopy);

                        // Recursively call
                        int[] minimax = minimax(boardState, cellHashMapCopy, islandsHashMapCopy, depth - 1, alpha, beta, true);
                        int score = minimax[0];

                        boardState[i][j] = '*';

                        // Update best move
                        if (score < minScore) {
                            //System.out.println("Min-score: " + score + ">" + minScore + " row: " + i + " column: " + j);
                            minScore = score;
                            bestMove[0] = score;
                            bestMove[1] = i;
                            bestMove[2] = j;
                        }

                        // Update beta
                        beta = Math.min(beta, score);

                        //Alfa-Beta Pruning
                        if (beta <= alpha) {
                            return bestMove;
                        }
                    }
                }
            }
            return bestMove;
        }
    }

    private int[] evaluationFunction(int[] bestMove, char[][] boardState, HashMap<String,Cell> cellHashMap, HashMap<Cell,CellRegion> islandsHashMap){
        int score = bestMove[0];

        // How many steps it took to reach a terminal node
        // Prioritize wins
        if(score == 1){
            score += (depth - bestMove[3]);
            score += 100;
        } else if (score == -1){
            score -= (depth - bestMove[3]);
            score -= 100;
        }

        // Prioritize central cells
        for (int i = 0; i < boardState.length; i++) {
            for (int j = 0; j < boardState[0].length; j++) {
                if (boardState[i][j] == 'X') { // IA Player
                    if (i > 1 && j > 1 && i < (boardState.length - 1) && j < (boardState[0].length - 1)) {
                        if (numberMoves < 3) { score++; }
                        if (i > 2 && j > 2 && i < (boardState.length - 2) && j < (boardState[0].length - 2)) {
                            score += 2;
                            break;
                        }
                    }
                } else if (boardState[i][j] == '0') { // Human Player
                    if (i > 1 && j > 1 && i < (boardState.length - 1) && j < (boardState[0].length - 1)) {
                        if (numberMoves < 3) { score--;}
                        if (i > 2 && j > 2 && i < (boardState.length - 2) && j < (boardState[0].length - 2)) {
                            score -= 2;
                            break;
                        }
                    }
                }
            }
        }

        // How many cells there are on each island,
        // for player X, prioritize the islands going from top to bottom and for player 0, prioritize the islands going from left to right,
        // for both players, prioritize the cells that can be connected in the future (bridge)
        for (Cell key : islandsHashMap.keySet()) {
            int x, y, cont = 0;
            boolean linearIsland = true;
            if (key.getState() == 2){ // IA Player
                if (islandsHashMap.get(key).size() > 1) {
                    for (Cell cell : islandsHashMap.get(key).getCells()) {
                        x = cell.getX();
                        y = cell.getY();
                        try {
                            // Linear islands
                            for (Cell cell2 : islandsHashMap.get(key).getCells()) {
                                if (x == (cell2.getX() - 1) && y == cell2.getY() || x == (cell2.getX() - 1) && y == (cell2.getY() + 1) || x == (cell2.getX() + 1) && y == (cell2.getY() - 1) ||
                                        x == (cell2.getX() + 1) && y == cell2.getY() || x == cell2.getX() && y == (cell2.getY() - 1) || x == cell2.getX() && y == (cell2.getY() + 1)) {
                                    cont++;
                                }
                                if (cont > 2) {
                                    linearIsland = false;
                                    break;
                                }
                            }
                            // islands (to the top)
                            // (i - 1, j), (i - 1, j + 1)
                            if (cellHashMap.get((x - 1) + "," + y).getState() == 2 || cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 2) {
                                score += 2;
                            }
                            // islands (to the bottom)
                            // (i + 1, j - 1), (i + 1, j)
                            if (cellHashMap.get((x + 1) + "," + (y - 1)).getState() == 2 || cellHashMap.get((x + 1) + "," + y).getState() == 2) {
                                score++;
                            }
                            // islands (to the left and right)
                            // (i, j - 1)
                            if (cellHashMap.get(x + "," + (y - 1)).getState() == 2 && cellHashMap.get(x + "," + (y + 1)).getState() == 2) {
                                score++;
                            }
                        } catch (NullPointerException e) {

                        }
                    }
                    if (linearIsland) {
                        score += islandsHashMap.get(key).size();
                    }
                }
                x = key.getX();
                y = key.getY();
                try {
                    // bridges (to the top)
                    if (cellHashMap.get((x - 1) + "," + y).getState() == 0 && cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 0 && cellHashMap.get((x - 2) + "," + (y + 1)).getState() == 2){
                        score =+ 2;
                    }
                    // bridges (to the bottom)
                    if (cellHashMap.get((x + 1) + "," + (y - 1)).getState() == 0 && cellHashMap.get((x + 1) + "," + y).getState() == 0 && cellHashMap.get((x + 2) + "," + (y - 1)).getState() == 2){
                        score++;
                    }
                    // bridges (to the right-top)
                    if (cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 0 && cellHashMap.get(x + "," + (y + 1)).getState() == 0 && cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 1){
                        score++;
                    }
                    // bridges (to the right-bottom)
                    if (cellHashMap.get((x + 1) + "," + y).getState() == 0 && cellHashMap.get(x + "," + (y + 1)).getState() == 0 && cellHashMap.get((x + 1) + "," + (y + 1)).getState() == 1){
                        score++;
                    }
                    // bridges (to the left-top)
                    if (cellHashMap.get((x - 1) + "," + y).getState() == 0 && cellHashMap.get(x + "," + (y - 1)).getState() == 0 && cellHashMap.get((x - 1) + "," + (y - 1)).getState() == 1) {
                        score++;
                    }
                    // bridges (to the left-bottom)
                    if (cellHashMap.get(x + "," + (y - 1)).getState() == 0 && cellHashMap.get((x + 1) + "," + (y - 1)).getState() == 0 && cellHashMap.get((x + 1) + "," + (y - 2)).getState() == 1) {
                        score++;
                    }

                    // spoil island (to the top)
                    if (cellHashMap.get((x - 1) + "," + y).getState() == 1 && cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 1){
                        score--;
                    }
                    // spoil island (to the bottom)
                    if (cellHashMap.get((x - 1) + "," + y).getState() == 1 && cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 1){
                        score--;
                    }

                    // spoil bridge (to the top)
                    if (cellHashMap.get((x - 2) + "," + (y + 1)).getState() == 1){
                        score--;
                    }
                    // spoil bridge (to the bottom)
                    if (cellHashMap.get((x + 2) + "," + (y - 1)).getState() == 1){
                        score--;
                    }

                    // save bridge (to the top)
                    if (cellHashMap.get((x - 1) + "," + y).getState() == 1 && cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 2 && cellHashMap.get((x - 2) + "," + (y + 1)).getState() == 2 ||
                            cellHashMap.get((x - 1) + "," + y).getState() == 2 && cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 1 && cellHashMap.get((x - 2) + "," + (y + 1)).getState() == 2){
                        score++;
                    }
                    // save bridge (to the bottom)
                    if (cellHashMap.get((x + 1) + "," + (y - 1)).getState() == 1 && cellHashMap.get((x + 1) + "," + y).getState() == 2 && cellHashMap.get((x + 2) + "," + (y - 1)).getState() == 2 ||
                            cellHashMap.get((x + 1) + "," + (y - 1)).getState() == 2 && cellHashMap.get((x + 1) + "," + y).getState() == 1 && cellHashMap.get((x + 2) + "," + (y - 1)).getState() == 2){
                        score++;
                    }
                } catch(NullPointerException e) {

                }
            } else if (key.getState() == 1){ // Human Player
                cont = 0;
                linearIsland = true;
                if (islandsHashMap.get(key).size() > 1){
                    for(Cell cell : islandsHashMap.get(key).getCells()){
                        x = cell.getX();
                        y = cell.getY();
                        try {
                            for (Cell cell2 : islandsHashMap.get(key).getCells()) {
                                if (x == (cell2.getX() - 1) && y == cell2.getY() || x == (cell2.getX() - 1) && y == (cell2.getY() + 1) || x == (cell2.getX() + 1) && y == (cell2.getY() - 1) ||
                                        x == (cell2.getX() + 1) && y == cell2.getY() || x == cell2.getX() && y == (cell2.getY() - 1) || x == cell2.getX() && y == (cell2.getY() + 1)) {
                                    cont++;
                                }
                                if (cont > 2) {
                                    linearIsland = false;
                                    break;
                                }
                            }
                            // islands (to the left)
                            // (i, j - 1)
                            if (cellHashMap.get(x + "," + (y - 1)).getState() == 1){
                                score--;
                            }
                            // islands (to the right)
                            // (i, j + 1)
                            if (cellHashMap.get(x + "," + (y + 1)).getState() == 1){
                                score--;
                            }
                            // islands (to the top and bottom)
                            // (i - 1, j), (i - 1, j + 1)
                            if (cellHashMap.get((x - 1) + "," + y).getState() == 1 || cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 1
                                    && cellHashMap.get((x + 1) + "," + (y - 1)).getState() == 1 || cellHashMap.get((x + 1) + "," + y).getState() == 1){
                                score--;
                            }

                        } catch(NullPointerException e) {

                        }
                    }
                    if (linearIsland){
                        score -= islandsHashMap.get(key).size();
                    }
                }
            }
            x = key.getX();
            y = key.getY();
            try {
                // bridges (to the right-top)
                if (cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 0 && cellHashMap.get(x + "," + (y + 1)).getState() == 0 && cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 1){
                    score =- 2;
                }
                // bridges (to the right-bottom)
                if (cellHashMap.get((x + 1) + "," + y).getState() == 0 && cellHashMap.get(x + "," + (y + 1)).getState() == 0 && cellHashMap.get((x + 1) + "," + (y + 1)).getState() == 1){
                    score =- 2;
                }
                // bridges (to the left-top)
                if (cellHashMap.get((x - 1) + "," + y).getState() == 0 && cellHashMap.get(x + "," + (y - 1)).getState() == 0 && cellHashMap.get((x - 1) + "," + (y - 1)).getState() == 1) {
                    score--;
                }
                // bridges (to the left-bottom)
                if (cellHashMap.get(x + "," + (y - 1)).getState() == 0 && cellHashMap.get((x + 1) + "," + (y - 1)).getState() == 0 && cellHashMap.get((x + 1) + "," + (y - 2)).getState() == 1) {
                    score--;
                }

                // spoil island (to the left)
                if (cellHashMap.get(x + "," + (y - 1)).getState() == 2){
                    score++;
                }
                // spoil island (to the right)
                if (cellHashMap.get(x + "," + (y + 1)).getState() == 2){
                    score++;
                }

                // spoil bridge (to the left-top)
                if (cellHashMap.get((x - 1) + "," + (y - 1)).getState() == 2){
                    score++;
                }
                // spoil bridge (to the left-bottom)
                if (cellHashMap.get((x + 1) + "," + (y - 2)).getState() == 2){
                    score++;
                }
                // spoil bridge (to the right-top)
                if (cellHashMap.get((x - 1) + "," + (y + 2)).getState() == 2){
                    score++;
                }
                // spoil bridge (to the right-bottom)
                if (cellHashMap.get((x + 1) + "," + (y + 1)).getState() == 2){
                    score++;
                }

                // save bridge (to the left-top)
                if (cellHashMap.get((x - 1) + "," + y).getState() == 1 && cellHashMap.get(x + "," + (y - 1)).getState() == 2 ||
                        cellHashMap.get((x - 1) + "," + y).getState() == 2 && cellHashMap.get(x + "," + (y - 1)).getState() == 1){
                    score--;
                }
                // save bridge (to the left-bottom)
                if (cellHashMap.get(x + "," + (y - 1)).getState() == 1 && cellHashMap.get((x + 1) + "," + (y - 1)).getState() == 2 ||
                        cellHashMap.get(x + "," + (y - 1)).getState() == 2 && cellHashMap.get((x + 1) + "," + (y - 1)).getState() == 1){
                    score--;
                }
                // save bridge (to the right-top, save top)
                if (cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 1 && cellHashMap.get(x + "," + (y + 1)).getState() == 2 ||
                        cellHashMap.get((x - 1) + "," + (y + 1)).getState() == 2 && cellHashMap.get(x + "," + (y + 1)).getState() == 1){
                    score--;
                }
                // save bridge (to the right-bottom, save top)
                if (cellHashMap.get(x + "," + (y + 1)).getState() == 1 && cellHashMap.get((x + 1) + "," + y).getState() == 2 ||
                        cellHashMap.get(x + "," + (y + 1)).getState() == 2 && cellHashMap.get((x + 1) + "," + y).getState() == 1){
                    score--;
                }
            } catch(NullPointerException e) {

            }
        }

        bestMove[0] = score;
        return bestMove;
    }

    public void search(Cell newCell, HashMap<String,Cell> cellHashMapCopy, HashMap<Cell,CellRegion> islandsHashMapCopy){

        int x = newCell.getX();
        int y = newCell.getY();

        int x1 = x+1;
        int x0 = x-1;

        int y1 = y+1;
        int y0 = y-1;

        String[] keys = {x1+","+y,x1+","+y0,x+","+y1,x+","+y0,x0+","+y,x0+","+y1};

        Cell[] neighbors = new Cell[6];
        int count = 0;

        for (String key : keys){

            x0 = Integer.parseInt(key.split(",")[0]);
            y0 = Integer.parseInt(key.split(",")[1]);

            if(x0 == -1){
                neighbors[count]=cellHashMapCopy.get("un");
                count++;
                continue;

            }else if(x0 == boardSize){
                neighbors[count]=cellHashMapCopy.get("dn");
                count++;
                continue;

            }else if(y0 == -1){
                neighbors[count]=cellHashMapCopy.get("ln");
                count++;
                continue;

            }else if(y0 == boardSize){
                neighbors[count]=cellHashMapCopy.get("rn");
                count++;
                continue;
            }

            neighbors[count]=cellHashMapCopy.get(key);
            count++;

        }

        for (Cell neighbor : neighbors){

            if (newCell.getState()==neighbor.getState()){

                CellRegion join;
                List<Cell> changes;

                if(newCell.getParent()==null){
                    newCell.setParent(neighbor.getParent());
                    join = islandsHashMapCopy.get(neighbor.getParent());
                    join.addCell(newCell);
                }else {
                    if(neighbor.getParent().equals(newCell.getParent())){
                        continue;
                    }else{
                        join = islandsHashMapCopy.get(newCell.getParent());
                        CellRegion delete = islandsHashMapCopy.get(neighbor.getParent());
                        changes = delete.getCells();
                        islandsHashMapCopy.remove(neighbor.getParent());

                        for (Cell cell : changes){
                            cell.setParent(newCell.getParent());
                            join.addCell(cell);
                        }
                    }
                }
            }
        }

        if(newCell.getParent()==null){
            newCell.setParent(newCell);

            CellRegion newRegion = new CellRegion(newCell);

            islandsHashMapCopy.put(newCell,newRegion);
        }

    }

    private char[][] copyMatrix(char[][] originalMatrix){
        char[][] copiedMatrix = new char[boardSize][boardSize];
        for (int i = 0; i < boardSize; i++) {
            System.arraycopy(originalMatrix[i], 0, copiedMatrix[i], 0, boardSize);
        }

        return copiedMatrix;
    }

    private HashMap<String,Cell> copyCellHashMap(char[][] boardState){
        HashMap<String,Cell> cellHashMapCopy = new HashMap<>();

        for (int i=0;i<boardSize;i++){
            for (int j=0;j<boardSize;j++){
                if (boardState[i][j] == '*'){
                    cellHashMapCopy.put(i + "," + j,new Cell(i,j));
                }else if(boardState[i][j] == '0'){
                    cellHashMapCopy.put(i + "," + j,new Cell(i,j,1));
                }else if(boardState[i][j] == 'X'){
                    cellHashMapCopy.put(i + "," + j,new Cell(i,j,2));
                }
            }
        }

        cellHashMapCopy.put("ln",new Cell(0,-1,1));
        cellHashMapCopy.put("rn",new Cell(0,boardSize,1));
        cellHashMapCopy.put("un",new Cell(-1,0,2));
        cellHashMapCopy.put("dn",new Cell(boardSize,0,2));

        return cellHashMapCopy;
    }

    private HashMap<Cell,CellRegion> copyIslandsHashMap(HashMap<String,Cell> cellHashMapCopy, HashMap<Cell,CellRegion> islandsHashMapOriginal){
        HashMap<Cell,CellRegion> islandsHashMapCopy = new HashMap<>();

        for (Map.Entry<Cell,CellRegion> entry : islandsHashMapOriginal.entrySet()) {
            Cell originalCell = entry.getKey();
            Cell copiedCell = null;

            for (Map.Entry<String,Cell> entryCell : cellHashMapCopy.entrySet()){
                if(entryCell.getValue().equals(originalCell)){
                    copiedCell = entryCell.getValue();
                    break;
                }
            }
            CellRegion originalRegion = entry.getValue();

            CellRegion copiedRegion = new CellRegion(copiedCell);

            for (Cell originalRegionCell : originalRegion.getCells()) {
                for (Map.Entry<String,Cell> entryCellCell : cellHashMapCopy.entrySet()){
                    if(entryCellCell.getValue().equals(copiedCell)){
                        continue;
                    }else if(entryCellCell.getValue().equals(originalRegionCell)){
                        Cell copiedRegionCell = entryCellCell.getValue();
                        copiedRegionCell.setParent(copiedCell);
                        copiedRegion.addCell(copiedRegionCell);
                        break;
                    }
                }
            }

            islandsHashMapCopy.put(copiedCell, copiedRegion);
        }

        return islandsHashMapCopy;
    }

    private int checkWinner(HashMap<String,Cell> cellHashMapCopy){
        if(cellHashMapCopy.get("ln").getParent().equals(cellHashMapCopy.get("rn").getParent())) return -1;
        else if(cellHashMapCopy.get("un").getParent().equals(cellHashMapCopy.get("dn").getParent())) return 1;
        else return 0;
    }

    private void printIslandMap(Map<Cell,CellRegion> map) {
        for (Map.Entry<Cell,CellRegion> entry : map.entrySet()) {
            Cell cell = entry.getKey();
            CellRegion region = entry.getValue();
            System.out.println("Parent: (" + cell.getX() + "," + cell.getY() + "), Region: " + region.toString());
        }
    }

    private void printCellMap(Map<String,Cell> map) {
        for (Map.Entry<String,Cell> entry : map.entrySet()) {
            String string = entry.getKey();
            Cell cell = entry.getValue();
            System.out.println("String: " + string + ", Cell: " + cell.toString());
        }
    }
}

