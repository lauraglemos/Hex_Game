package com.example.hexgui;
public class Cell{
    private int x;
    private int y;
    private int state; //STATE 0: UNASSIGNED; STATE 1: PLAYER 0; STATE 2: PLAYER X;
    private Cell parent;

    public Cell (){

    }

    public Cell (int x,int y){
        this.x = x;
        this.y = y;
        this.state = 0;
    }

    public Cell (int x,int y,int state){
        this.x = x;
        this.y = y;
        this.state = state;
        this.parent = this;
    }

    public int getX(){
        return this.x;
    }

    public int getY(){
        return this.y;
    }

    public int getState(){
        return this.state;
    }

    public Cell getParent(){
        return this.parent;
    }

    public void setState(int state){
        this.state = state;
    }

    public void setParent(Cell parent){
        this.parent = parent;
    }

    public String toString(){
        return this.x+","+this.y;
    }

    public boolean equals (Cell cell){
        if((cell.getX()==this.getX())&&(cell.getY()==this.getY())) return true;
        else return false;
    }
}