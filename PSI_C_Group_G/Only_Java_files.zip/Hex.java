
package com.example.hexgui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Hex {
    private char[][] matrix;
    private static HashMap<String,Cell> cellHashMap = new HashMap<>() ;
    private boolean isHumanTurn;
    public static int boardSize = 7;

    public static int positiveInfinity = Integer.MAX_VALUE;
    public static int negativeInfinity = Integer.MIN_VALUE;
    public static int depth;
    public int numberMoves;
    Minimax minimax;

    private HashMap<Cell,CellRegion> islands = new HashMap<>();

    public Hex(int boardSize) {
        this.boardSize = boardSize;
        initialize();
        depth = 2;
        minimax = new Minimax(depth);
        isHumanTurn = true;
        numberMoves = 0;
    }

    public char getCellValue(int x, int y) {
        return matrix[x][y];
    }

    public boolean isHumanTurn() {
        return isHumanTurn;
    }

    public void toggleTurn() {
        isHumanTurn = !isHumanTurn;
    }

    public void makeMove(int x, int y, char player) {
        numberMoves++;
        minimax.setNumberMoves(numberMoves);
        if (numberMoves == 2){
            depth++;
            minimax.setDepth(depth);
        }
        if (numberMoves == 13){
            depth++;
            minimax.setDepth(depth);
        }

        if (x < boardSize && y < boardSize && x >= 0 && y >= 0 && isHumanTurn && matrix[x][y] == '*') {
            matrix[x][y] = player;
            cellHashMap.get(getKey(x, y)).setState(player == '0' ? 1 : 2);
            search(cellHashMap.get(getKey(x, y)));
            toggleTurn(); // Toggle the turn after a valid move
        }
    }

    public int[] makeAIMove() {
        if (!isHumanTurn) {
            char[][] actualBoardState = copyMatrix(matrix);

            int[] bestMove = minimax.minimax(actualBoardState,cellHashMap,islands,depth,negativeInfinity,positiveInfinity,true);

            int pos1,pos2;

            pos1 = bestMove[1];
            pos2 = bestMove[2];

            matrix[pos1][pos2] = 'X';  // Assuming 'X' represents the AI player
            cellHashMap.get(getKey(pos1, pos2)).setState(2);  // Update the Cell status
            search(cellHashMap.get(getKey(pos1, pos2)));
            toggleTurn();  // Toggle the turn after the AI makes a move

            return new int[]{pos1, pos2};

            // Uncomment to play against random

            /**
             Random random = new Random();
             int aiX, aiY;

             do {
             aiX = random.nextInt(boardSize);
             aiY = random.nextInt(boardSize);
             } while (matrix[aiX][aiY] != '*');

             matrix[aiX][aiY] = 'X';  // Assuming 'X' represents the AI player
             cellHashMap.get(getKey(aiX, aiY)).setState(2);  // Update the Cell status
             search(cellHashMap.get(getKey(aiX, aiY)));
             toggleTurn();  // Toggle the turn after the AI makes a move

             return new int[]{aiX, aiY};
             }

             */

        }

        return null; // Return null if it's not the AI's turn
    }

    private void initialize(){

        matrix = new char[boardSize][boardSize];

        Cell aux;

        for (int i=0;i<boardSize;i++){
            for (int j=0;j<boardSize;j++){
                matrix[i][j]='*';
                aux = new Cell(i,j);
                cellHashMap.put(aux.toString(), aux);
            }
        }

        Cell leftNode = new Cell(0,-1,1);
        Cell rightNode = new Cell(0,boardSize,1);
        Cell upNode = new Cell(-1,0,2);
        Cell downNode = new Cell(boardSize,0,2);

        cellHashMap.put("ln",leftNode);
        cellHashMap.put("rn",rightNode);
        cellHashMap.put("un",upNode);
        cellHashMap.put("dn",downNode);

        islands.put(leftNode,new CellRegion(leftNode));
        islands.put(rightNode,new CellRegion(rightNode));
        islands.put(upNode,new CellRegion(upNode));
        islands.put(downNode,new CellRegion(downNode));

    }

    private void search(Cell newCell){

        int x = newCell.getX();
        int y = newCell.getY();

        int x1 = x+1;
        int x0 = x-1;

        int y1 = y+1;
        int y0 = y-1;

        String[] keys = {x1+","+y,x1+","+y0,x+","+y1,x+","+y0,x0+","+y,x0+","+y1};

        Cell[] neighbors = new Cell[6];
        int count = 0;

        for (String key : keys){

            x0 = Integer.parseInt(key.split(",")[0]);
            y0 = Integer.parseInt(key.split(",")[1]);

            if(x0 == -1){
                neighbors[count]=cellHashMap.get("un");
                count++;
                continue;

            }else if(x0 == boardSize){
                neighbors[count]=cellHashMap.get("dn");
                count++;
                continue;

            }else if(y0 == -1){
                neighbors[count]=cellHashMap.get("ln");
                count++;
                continue;

            }else if(y0 == boardSize){
                neighbors[count]=cellHashMap.get("rn");
                count++;
                continue;
            }

            neighbors[count]=cellHashMap.get(key);
            count++;
        }


        for (Cell neighbor : neighbors){

            if (newCell.getState()==neighbor.getState()){

                CellRegion join;

                if(newCell.getParent()==null){
                    newCell.setParent(neighbor.getParent());
                    join = islands.get(neighbor.getParent());
                    join.addCell(newCell);
                }else {
                    if(neighbor.getParent().equals(newCell.getParent())){
                        continue;
                    }else{
                        join = islands.get(newCell.getParent());
                        CellRegion delete = islands.get(neighbor.getParent());
                        List<Cell> changes = delete.getCells();
                        islands.remove(neighbor.getParent());

                        for (Cell cell : changes){
                            cell.setParent(newCell.getParent());
                            join.addCell(cell);
                        }
                    }
                }
            }
        }

        if(newCell.getParent()==null){
            newCell.setParent(newCell);

            CellRegion newRegion = new CellRegion(newCell);

            islands.put(newCell,newRegion);
        }

    }


    private String getKey(int x, int y) {
        return x + "," + y;
    }

    private char[][] copyMatrix(char[][] originalMatrix){
        char[][] copiedMatrix = new char[boardSize][boardSize];
        for (int i = 0; i < boardSize; i++) {
            System.arraycopy(originalMatrix[i], 0, copiedMatrix[i], 0, boardSize);
        }

        return copiedMatrix;
    }

    public int checkWinner() {
        if (cellHashMap.get("ln").getParent().equals(cellHashMap.get("rn").getParent())) {
            return 1;
        } else if (cellHashMap.get("un").getParent().equals(cellHashMap.get("dn").getParent())) {
            return 2;
        } else {
            return 0;
        }
    }
}