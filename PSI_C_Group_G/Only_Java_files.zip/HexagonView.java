package com.example.hexgui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.AsyncTask;
import android.view.MotionEvent;
import android.view.View;
import android.content.Intent;


public class HexagonView extends View implements View.OnTouchListener {

    private Context context;

    private static final int BOARD_SIZE = 7;
    private static final float HEXAGON_SPACING_FACTOR = 0.8f;
    private static final float HEXAGON_SIZE_FACTOR = 1.2f;

    private Paint borderPaint;
    private Paint borderBLUE;
    private Paint borderRED;
    private Paint fillPaint;
    private Hex hexGame;  // Instance of the Hex class to manage the game logic

    public HexagonView(Context context) {
        super(context);

        this.context = context;

        borderPaint = new Paint();
        borderPaint.setAntiAlias(true);
        borderPaint.setColor(Color.BLACK);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(3);

        borderRED = new Paint();
        borderRED.setAntiAlias(true);
        borderRED.setColor(Color.RED);
        borderRED.setStyle(Paint.Style.STROKE);
        borderRED.setStrokeWidth(10);

        borderBLUE = new Paint();
        borderBLUE.setAntiAlias(true);
        borderBLUE.setColor(Color.BLUE);
        borderBLUE.setStyle(Paint.Style.STROKE);
        borderBLUE.setStrokeWidth(10);

        fillPaint = new Paint();
        fillPaint.setAntiAlias(true);
        fillPaint.setStyle(Paint.Style.FILL);

        hexGame = new Hex(BOARD_SIZE);  // Initialize the game with the board size

        setOnTouchListener(this);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();

        float hexagonWidth = width / (BOARD_SIZE + (BOARD_SIZE - 1) * 0.5f) * HEXAGON_SIZE_FACTOR;
        float hexagonHeight = hexagonWidth * 0.866f;

        float totalBoardHeight = BOARD_SIZE * hexagonHeight * HEXAGON_SPACING_FACTOR;
        float offsetY = (height - totalBoardHeight) / 2;

        int pos;

        for (int i = 0; i < BOARD_SIZE; i++) {
            int hexagonsInRow = BOARD_SIZE;

            for (int j = 0; j < hexagonsInRow; j++) {
                float hexagonX = j * hexagonWidth * HEXAGON_SPACING_FACTOR;
                float hexagonY = i * hexagonHeight * HEXAGON_SPACING_FACTOR + offsetY;

                float offsetX = i * (hexagonWidth * HEXAGON_SPACING_FACTOR / 2);
                hexagonX += offsetX;

                float[] hexagonVertices = calculateHexagonVertices(hexagonX, hexagonY, hexagonWidth, hexagonHeight);

                char cellValue = hexGame.getCellValue(i, j);

                if (cellValue == '*') {
                    fillPaint.setColor(Color.WHITE);
                } else if (cellValue == '0') {
                    fillPaint.setColor(Color.RED);
                } else if (cellValue == 'X') {
                    fillPaint.setColor(Color.BLUE);
                }
                pos = 0;
                if(i==0) {
                    pos = 1;
                    if(j==0) pos = 5;
                    if(j==6) pos = 6;
                }
                else if(i==6){
                    pos = 2;
                    if(j==0) pos = 8;
                    if(j==6) pos = 7;
                }
                else if(j==0) pos = 3;
                else if(j==6) pos = 4;
                drawHexagon(canvas, hexagonVertices,pos);
            }
        }
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        int width = getWidth();
        int height = getHeight();

        float hexagonWidth = width / (BOARD_SIZE + (BOARD_SIZE - 1) * 0.5f) * HEXAGON_SIZE_FACTOR;
        float hexagonHeight = hexagonWidth * 0.866f;

        float totalBoardHeight = BOARD_SIZE * hexagonHeight * HEXAGON_SPACING_FACTOR;
        float offsetY = (height - totalBoardHeight) / 2;

        for (int i = 0; i < BOARD_SIZE; i++) {
            int hexagonsInRow = BOARD_SIZE;

            for (int j = 0; j < hexagonsInRow; j++) {
                float hexagonX = j * hexagonWidth * HEXAGON_SPACING_FACTOR;
                float hexagonY = i * hexagonHeight * HEXAGON_SPACING_FACTOR + offsetY;

                float offsetX = i * (hexagonWidth * HEXAGON_SPACING_FACTOR / 2);
                hexagonX += offsetX;

                float[] hexagonVertices = calculateHexagonVertices(hexagonX, hexagonY, hexagonWidth, hexagonHeight);

                if (isPointInHexagon(x, y, hexagonVertices)) {

                    // Check if the selected hexagon is empty
                    if (hexGame.getCellValue(i, j) == '*') {

                        // Human's move
                        invalidate();  // Redraw the view
                        hexGame.makeMove(i, j, '0');

                        // Check for a winner
                        int winner = hexGame.checkWinner();
                        if (winner == 1 || winner == 2) {
                            // Start a new activity if there is a winner
                            Intent intent = new Intent(context, ResultActivity.class);
                            intent.putExtra("winner", winner);
                            context.startActivity(intent);
                            return true;
                        }

                        // AI's move
                        // Make sure it's the AI's turn
                        if (!hexGame.isHumanTurn()) {
                            AIMove();
                        }

                        return true;
                    }
                }
            }
        }

        return false;
    }

    public void AIMove() {
        new AsyncTask<Void, Void, int[]>() {
            @Override
            protected int[] doInBackground(Void... voids) {
                // AI in background
                return hexGame.makeAIMove();
            }

            @Override
            protected void onPostExecute(int[] aiMove) {
                invalidate();  // Redraw the view

                // Check for a winner
                int winner = hexGame.checkWinner();
                if (winner == 1 || winner == 2) {
                    // Start a new activity if there is a winner
                    Intent intent = new Intent(context, ResultActivity.class);
                    intent.putExtra("winner", winner);
                    context.startActivity(intent);
                }
            }
        }.execute();  // Run AsyncTask
    }

    private boolean isPointInHexagon(float x, float y, float[] hexagonVertices) {
        int i, j;
        boolean result = false;
        for (i = 0, j = hexagonVertices.length - 2; i < hexagonVertices.length - 1; j = i, i += 2) {
            if ((hexagonVertices[i + 1] > y) != (hexagonVertices[j + 1] > y) &&
                    (x < (hexagonVertices[j] - hexagonVertices[i]) * (y - hexagonVertices[i + 1]) / (hexagonVertices[j + 1] - hexagonVertices[i + 1]) + hexagonVertices[i]))
                result = !result;
        }
        return result;
    }

    private float[] calculateHexagonVertices(float x, float y, float width, float height) {
        float[] vertices = new float[12];

        float centerX = x + width / 2f;
        float centerY = y + height / 2f;
        float radius = Math.min(width / 2f, height / 2f);

        for (int i = 0; i < 6; i++) {
            float angleRad = (float) (Math.PI / 3 * i);

            float rotatedAngle = angleRad + (float) Math.PI / 2;

            float vertexX = centerX + radius * (float) Math.cos(rotatedAngle);
            float vertexY = centerY + radius * (float) Math.sin(rotatedAngle);
            vertices[i * 2] = vertexX;
            vertices[i * 2 + 1] = vertexY;
        }

        return vertices;
    }

    private void drawHexagon(Canvas canvas, float[] vertices,int pos) {

        Paint[] paints = new Paint[]{borderPaint,borderBLUE,borderRED};

        for (int i = 0; i < vertices.length; i += 2) {
            Path hexagonPath = new Path();
            hexagonPath.moveTo(vertices[i], vertices[i + 1]);
            int nextIndex = (i + 2) % vertices.length;
            hexagonPath.lineTo(vertices[nextIndex], vertices[nextIndex + 1]);

            Paint paintToUse;
            switch (pos) {
                case 1: // Lado izquierdo
                    paintToUse = (i == 4 || i == 6) ? paints[1] : paints[0];
                    break;
                case 2: // Lado derecho
                    paintToUse = (i == 0 || i == 10) ? paints[1] : paints[0];
                    break;
                case 3: // Dos lados superiores
                    paintToUse = (i == 0 || i == 2) ? paints[2] : paints[0];
                    break;
                case 4: // Dos lados inferiores
                    paintToUse = (i == 6 || i == 8) ? paints[2] : paints[0];
                    break;
                case 5: // Lados superiores con paints[1], izquierdo con paints[2]
                    if (i == 0 || i == 2) {
                        paintToUse = paints[2];
                    } else if (i == 4 || i == 6) {
                        paintToUse = paints[1];
                    } else {
                        paintToUse = paints[0];
                    }
                    break;
                case 6: // Lados superiores con paints[1], izquierdo con paints[2]
                    if (i == 8) {
                        paintToUse = paints[2];
                    } else if (i == 4 || i == 6) {
                        paintToUse = paints[1];
                    } else {
                        paintToUse = paints[0];
                    }
                    break;
                case 7: // Lados superiores con paints[1], izquierdo con paints[2]
                    if (i == 6 || i == 8) {
                        paintToUse = paints[2];
                    } else if (i == 0 || i == 10) {
                        paintToUse = paints[1];
                    } else {
                        paintToUse = paints[0];
                    }
                    break;
                case 8: // Lados superiores con paints[1], izquierdo con paints[2]
                    if (i == 2) {
                        paintToUse = paints[2];
                    } else if (i == 0 || i == 10) {
                        paintToUse = paints[1];
                    } else {
                        paintToUse = paints[0];
                    }
                    break;
                default: // pos = 0 o cualquier otro caso
                    paintToUse = paints[0];
            }

            canvas.drawPath(hexagonPath, paintToUse);
            hexagonPath.close();
        }

        Path fillPath = new Path();
        fillPath.moveTo(vertices[0], vertices[1]);
        for (int i = 2; i < vertices.length; i += 2) {
            fillPath.lineTo(vertices[i], vertices[i + 1]);
        }
        fillPath.close();
        canvas.drawPath(fillPath, fillPaint);
    }

}




















