package com.example.hexgui;
import java.util.ArrayList;
import java.util.List;

public class CellRegion{
    private List<Cell> cells;
    private Cell parent;

    public CellRegion(Cell parent) {
        this.cells = new ArrayList<>();
        this.parent = parent;
        cells.add(parent);
    }

    public void addCell(Cell cell) {
        cells.add(cell);
    }

    public List<Cell> getCells() {
        return cells;
    }

    public Cell getParent() {
        return parent;
    }

    public void setParent(Cell parent) {
        this.parent = parent;
    }

    public String toString(){
        String string ="";
        for (Cell cell : cells){
            string += "["+cell.toString()+"]";
        }
        return string;
    }

    public int size() {
        return cells.size();
    }

}